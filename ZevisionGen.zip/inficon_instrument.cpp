#include "inficon_instrument.h"

InficonInstrument::InficonInstrument(QObject *parent) : QObject(parent)
{

}
